﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace PokerGenys.Domain.Models
{
    public class DealerShift
    {
        [BsonId]
        public Guid Id { get; set; } = Guid.NewGuid();

        // Enlace al dealer que está trabajando
        public Guid DealerId { get; set; }

        // Enlace a la mesa (si es específico)
        public Guid? TableId { get; set; }

        // Enlace a la jornada operativa
        public Guid WorkingDayId { get; set; }

        public DateTime StartTime { get; set; } = DateTime.UtcNow;
        public DateTime? EndTime { get; set; }

        // Totales calculados (para nómina)
        public decimal TotalTipsEarned { get; set; } = 0;
        public decimal TotalHoursWorked { get; set; } = 0;

        public string? Notes { get; set; }
    }
}