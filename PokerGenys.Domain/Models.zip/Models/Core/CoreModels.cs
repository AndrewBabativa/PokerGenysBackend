﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using PokerGenys.Domain.Enums; // Usamos los Enums centralizados
using System;
using System.Collections.Generic;

namespace PokerGenys.Domain.Models.Core
{
    // ===========================================
    // 1. JORNADA OPERATIVA (WORKING DAY)
    // ===========================================
    public class WorkingDay
    {
        [BsonId]
        public Guid Id { get; set; } = Guid.NewGuid();

        public DateTime StartAt { get; set; }
        public DateTime? EndAt { get; set; }

        [BsonRepresentation(BsonType.String)]
        public WorkingDayStatus Status { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? ClosedAt { get; set; }

        public string? Notes { get; set; }

        // CAMPOS AGREGADOS (Para el reporte final que ya implementamos)
        public decimal TotalCashIn { get; set; } = 0;
        public decimal TotalCashOut { get; set; } = 0;
        public decimal TotalRake { get; set; } = 0;
        public decimal TotalJackpotCollected { get; set; } = 0;
    }


    // ===========================================
    // 2. JUGADOR (PLAYER)
    // ===========================================
    public class Player
    {
        [BsonId]
        public Guid Id { get; set; } = Guid.NewGuid();

        // --- 1. IDENTIDAD ---
        public string FirstName { get; set; } = string.Empty;
        public string? LastName { get; set; }
        public string? Nickname { get; set; }
        public string DocumentId { get; set; } = string.Empty; // Hacer no-nullable si es obligatorio para el club

        public string? PhotoUrl { get; set; }

        // --- 2. CONTACTO ---
        public string? Email { get; set; }
        public string? PhoneNumber { get; set; }
        public string? Address { get; set; }
        public DateTime? BirthDate { get; set; }

        // --- 3. ESTADO Y CLASIFICACIÓN ---
        [BsonRepresentation(BsonType.String)]
        public PlayerStatus Status { get; set; } = PlayerStatus.Active;

        [BsonRepresentation(BsonType.String)]
        public PlayerType Type { get; set; } = PlayerType.Standard;

        public string? InternalNotes { get; set; }

        // --- 4. FINANZAS Y ESTADÍSTICAS ---
        public PlayerFinancials Financials { get; set; } = new PlayerFinancials();
        public PlayerStats Stats { get; set; } = new PlayerStats();

        // --- 5. SISTEMA ---
        public Dictionary<string, object>? Metadata { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? UpdatedAt { get; set; }

        // Helper: Nombre completo para búsquedas y display
        [BsonIgnore]
        public string DisplayName => !string.IsNullOrEmpty(Nickname)
            ? Nickname
            : $"{FirstName} {LastName}".Trim();

        // Helper para búsquedas de Repositorio
        [BsonIgnore]
        public string FullName => $"{FirstName} {LastName}".Trim();
    }

    // Sub-documento para Finanzas (Embebido)
    public class PlayerFinancials
    {
        public decimal CreditBalance { get; set; } = 0;
        public decimal TotalDebt { get; set; } = 0;
        public decimal TotalRakeGenerated { get; set; } = 0;
    }

    // Sub-documento para Estadísticas de Juego (Embebido)
    public class PlayerStats
    {
        public int TotalSessionsPlayed { get; set; } = 0;
        public int TotalTournamentsPlayed { get; set; } = 0;
        public int TournamentsWon { get; set; } = 0;
        public DateTime? LastVisit { get; set; }
        public int LoyaltyPoints { get; set; } = 0;
    }

    // ===========================================
    // 3. DEALER (STAFF) <-- ¡INTEGRADO!
    // ===========================================
    public class Dealer
    {
        [BsonId]
        public Guid Id { get; set; } = Guid.NewGuid();

        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string? Nickname { get; set; }
        public string DocumentId { get; set; } = string.Empty;

        [BsonRepresentation(BsonType.String)]
        public DealerStatus Status { get; set; } = DealerStatus.Active;

        public decimal HourlyRate { get; set; } // Tarifa por hora para nómina
        public string? PhotoUrl { get; set; }

        public DateTime HireDate { get; set; } = DateTime.UtcNow;
        public Dictionary<string, object>? Metadata { get; set; }

        [BsonIgnore]
        public string FullName => $"{FirstName} {LastName}".Trim();
    }
}