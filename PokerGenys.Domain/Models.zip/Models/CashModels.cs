﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using PokerGenys.Domain.Enums;
using PokerGenys.Domain.Interfaces;
using System;
using System.Collections.Generic;

namespace PokerGenys.Domain.Models
{
    // ==========================================
    // 1. MESA DE CASH (Configuración y Estado)
    // ==========================================
    public class CashTable
    {
        [BsonId]
        public Guid Id { get; set; } = Guid.NewGuid();

        public Guid WorkingDayId { get; set; } // Enlace a la jornada

        public string Name { get; set; } = string.Empty;
        public string Blinds { get; set; } = "1k/2k"; // Ej: 2/5, 5/10

        [BsonRepresentation(BsonType.String)]
        public TableStatus Status { get; set; } = TableStatus.Open;

        public int MaxPlayers { get; set; } = 9;
        public decimal MinBuyIn { get; set; } // Antes InitialBuyInBase
        public decimal? MaxBuyIn { get; set; }

        public Guid? CurrentDealerId { get; set; }

        // Métricas rápidas
        public decimal TotalRake { get; set; } = 0;
        public decimal TotalJackpot { get; set; } = 0;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? ClosedAt { get; set; }

        // Lista de jugadores sentados actualmente (Optimización de lectura)
        public List<Guid> ActivePlayerIds { get; set; } = new List<Guid>();
    }

    // ==========================================
    // 2. LISTA DE ESPERA (WAITLIST)
    // ==========================================
    public class WaitList
    {
        [BsonId]
        public Guid Id { get; set; } = Guid.NewGuid();

        public Guid TableId { get; set; }
        public Guid PlayerId { get; set; }
        public string PlayerName { get; set; } = string.Empty; // Snapshot del nombre

        [BsonRepresentation(BsonType.String)]
        public WaitlistStatus Status { get; set; } = WaitlistStatus.Pending;

        public string? Notes { get; set; }
        public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;
    }

    // ==========================================
    // 3. SESIÓN DE JUGADOR (CashSession)
    // ==========================================
    public class CashSession
    {
        [BsonId]
        public Guid Id { get; set; } = Guid.NewGuid();

        // IDs Relacionales
        public Guid WorkingDayId { get; set; } // Alias de DayId (Estandarizado)
        public Guid TableId { get; set; }
        public Guid PlayerId { get; set; }

        // Estado del Juego
        public decimal CurrentStack { get; set; } // Fichas actuales en mesa
        public DateTime StartTime { get; set; } = DateTime.UtcNow;
        public DateTime? EndTime { get; set; }

        // Métricas Financieras (Tus campos originales optimizados)
        public decimal TotalBuyIn { get; set; } // Suma de entradas
        public decimal TotalCashOut { get; set; } // Suma de retiros

        // Propiedad calculada: ¿Ganó o Perdió?
        public decimal NetResult => TotalCashOut - TotalBuyIn;

        // Historial embebido (Opcional, pero recomendado mantener sincronizado)
        public List<CashTransaction> Transactions { get; set; } = new List<CashTransaction>();

        public Dictionary<string, object>? Metadata { get; set; }
    }

    // ==========================================
    // 4. TRANSACCIÓN FINANCIERA (Optimized)
    // ==========================================
    public class CashTransaction : IFinancialTransaction
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid SessionId { get; set; }

        // CRÍTICO: Necesario para que WorkingDayRepository pueda sumar la caja sin hacer Joins
        public Guid WorkingDayId { get; set; }

        [BsonRepresentation(BsonType.String)]
        public CashTransactionType Type { get; set; }

        public decimal Amount { get; set; }

        [BsonRepresentation(BsonType.String)]
        public PaymentMethod PaymentMethod { get; set; }

        [BsonRepresentation(BsonType.String)]
        public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Paid;

        public string? TransferProof { get; set; }
        public string Description { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        // --- IMPLEMENTACIÓN DE INTERFAZ INTELIGENTE ---
        // Calculamos la categoría al vuelo. No la guardamos en BD para evitar inconsistencias.
        public TransactionCategory Category => Type switch
        {
            CashTransactionType.BuyIn => TransactionCategory.Income,
            CashTransactionType.Rebuy => TransactionCategory.Income,
            CashTransactionType.RestaurantSale => TransactionCategory.Income,

            CashTransactionType.CashOut => TransactionCategory.Outcome,

            // El Rake es ingreso para la casa (Income)
            CashTransactionType.HouseRake => TransactionCategory.Income,

            _ => TransactionCategory.Neutral
        };

        // Origen fijo para reportes
        public OperationSource Source => OperationSource.CashGame;
    }
}