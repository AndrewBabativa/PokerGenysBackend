﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using PokerGenys.Domain.Enums;
using PokerGenys.Domain.Interfaces;
using System;
using System.Collections.Generic;

namespace PokerGenys.Domain.Models
{
    public class Tournament
    {
        [BsonId]
        public Guid Id { get; set; } = Guid.NewGuid();

        public Guid WorkingDayId { get; set; }

        public string Name { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public string Status { get; set; } = "Scheduled";

        public decimal BuyIn { get; set; }
        public decimal Fee { get; set; }
        public decimal Guaranteed { get; set; }
        public int StartingChips { get; set; }

        // --- TUS CONFIGURACIONES ---
        public SeatingConfiguration Seating { get; set; } = new();
        public RebuyConfig RebuyConfig { get; set; } = new();
        public AddonConfig AddonConfig { get; set; } = new();
        public BountyConfig BountyConfig { get; set; } = new();

        public List<BlindLevel> Levels { get; set; } = new();
        public List<PayoutTier> Payouts { get; set; } = new();

        public List<TournamentTable> Tables { get; set; } = new();
        public List<TournamentRegistration> Registrations { get; set; } = new();

        // --- ESTADO ---
        public DateTime? StartTime { get; set; }   // Hora exacta de inicio
        public int CurrentLevel { get; set; } = 1; // Nivel actual
        public decimal PrizePool { get; set; } = 0;

        // Opcional: Mantener lista local, aunque se recomienda usar Repo separado
        public List<TournamentTransaction> Transactions { get; set; } = new();
    }

    // ... (Tus clases de config: Seating, Rebuy, Addon, Bounty, BlindLevel, PayoutTier se quedan IGUAL) ...
    // COPIALAS AQUI TAL CUAL LAS TENIAS EN TU MENSAJE ANTERIOR

    public class SeatingConfiguration { public int Tables { get; set; } = 1; public int SeatsPerTable { get; set; } = 9; public int FinalTableSize { get; set; } = 9; public string InitialSeatingMode { get; set; } = "Standard"; public string TableBalancingMode { get; set; } = "None"; }
    public class RebuyConfig { public bool Enabled { get; set; } public decimal RebuyCost { get; set; } public decimal RebuyHouseFee { get; set; } public int RebuyChips { get; set; } public bool AutoRebuy { get; set; } public int MaxRebuysPerPlayer { get; set; } public int UntilLevel { get; set; } }
    public class AddonConfig { public bool Enabled { get; set; } public decimal AddonCost { get; set; } public decimal AddonHouseFee { get; set; } public int AddonChips { get; set; } public int MaxAddonsPerPlayer { get; set; } public int AllowedLevel { get; set; } }
    public class BountyConfig { public bool Enabled { get; set; } public decimal BountyCost { get; set; } public decimal PrizePerPlayer { get; set; } public string Type { get; set; } = "normal"; public decimal ProgressivePercentage { get; set; } }
    public class BlindLevel { public Guid Id { get; set; } = Guid.NewGuid(); public int LevelNumber { get; set; } public int DurationSeconds { get; set; } public int SmallBlind { get; set; } public int BigBlind { get; set; } public int Ante { get; set; } public bool IsBreak { get; set; } public bool AllowRebuy { get; set; } public bool AllowAddon { get; set; } }
    public class PayoutTier { public Guid Id { get; set; } = Guid.NewGuid(); public int Rank { get; set; } public decimal Percentage { get; set; } public decimal FixedAmount { get; set; } }

    public class TournamentTable
    {
        [BsonId]
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public int TableNumber { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Status { get; set; } = "Scheduled";
        public DateTime? ClosedAt { get; set; }
        public Guid? CurrentDealerId { get; set; }
        public int MaxSeats { get; set; } = 9;
    }

    public class TournamentRegistration
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid TournamentId { get; set; }
        public string PlayerName { get; set; } = string.Empty;
        public string DocumentId { get; set; } = string.Empty;
        public bool IsNewUser { get; set; }
        public string? SeatId { get; set; }
        public string? TableId { get; set; }
        public int Chips { get; set; }
        public string Status { get; set; } = "Active";
        public decimal TotalBuyInPaid { get; set; }
        public decimal TotalPayoutReceived { get; set; }
        public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;
        public DateTime? EliminatedAt { get; set; }
        public decimal? PayoutAmount { get; set; }
    }

    // ==========================================
    //        TRANSACCIÓN FINANCIERA CORREGIDA
    // ==========================================
    public class TournamentTransaction : IFinancialTransaction
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid TournamentId { get; set; }
        public Guid WorkingDayId { get; set; }
        public Guid? RegistrationId { get; set; }

        // ESTE ES TU ENUM ESPECIFICO (NO LO QUITAMOS)
        [BsonRepresentation(BsonType.String)]
        public TournamentTransactionType Type { get; set; }

        public decimal Amount { get; set; }

        [BsonRepresentation(BsonType.String)]
        public PaymentMethod PaymentMethod { get; set; }

        [BsonRepresentation(BsonType.String)]
        public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Paid;

        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string Description { get; set; } = string.Empty;

        // Implementación de Interfaz para Reportes
        // Aquí traducimos TU tipo específico a la categoría genérica Income/Outcome
        public TransactionCategory Category => Type switch
        {
            TournamentTransactionType.BuyIn => TransactionCategory.Income,
            TournamentTransactionType.Rebuy => TransactionCategory.Income,
            TournamentTransactionType.AddOn => TransactionCategory.Income,
            TournamentTransactionType.RestaurantSale => TransactionCategory.Income,

            // Salidas de dinero
            TournamentTransactionType.PrizePayment => TransactionCategory.Outcome,

            // Neutros o Ingresos internos (Rake)
            // El rake es ingreso para la casa, pero no suma al pozo. 
            // Para el flujo de caja es Income.
            TournamentTransactionType.HouseRake => TransactionCategory.Income,

            _ => TransactionCategory.Neutral
        };

        // Propiedad requerida por la interfaz
        public OperationSource Source => OperationSource.Tournament;
    }

    public class TournamentState
    {
        public int CurrentLevel { get; set; }
        public int TimeRemaining { get; set; }
        public string Status { get; set; }
        public int RegisteredCount { get; set; }
        public decimal PrizePool { get; set; }
    }
}